package dev.clempe.etherwallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
