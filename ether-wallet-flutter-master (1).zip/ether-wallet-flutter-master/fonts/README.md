drag config.json file in https://www.fluttericon.com/ to pre select icons used in this project
after downloading the new set of icons, follow the downloaded dart file comments instructions.